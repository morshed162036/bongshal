    <!-- BEGIN: Header-->
    <div class="header-navbar-shadow"></div>
    <nav class="header-navbar main-header-navbar navbar-expand-lg navbar navbar-with-menu fixed-top ">
        <div class="navbar-wrapper">
            <div class="navbar-container content">
                <div class="navbar-collapse" id="navbar-mobile">
                    <div class="mr-auto float-left bookmark-wrapper d-flex align-items-center">
                        
                    </div>
                    <ul class="nav navbar-nav float-right">
                        
                        <li class="dropdown dropdown-user nav-item"><a
                                class="dropdown-toggle nav-link dropdown-user-link" href="#"
                                data-toggle="dropdown">
                                <div class="user-nav d-sm-flex d-none">
                                    <span
                                        class="user-name"><?php echo e(Auth::guard('web')->user()->name); ?></span>
                                </div><span><img class="round"
                                        src="<?php if((Auth::guard('web')->user()->id == 1) && $company->favicon): ?>
                                        <?php echo e(asset('images/setting/'.$company->favicon)); ?>

                                        <?php elseif(Auth::guard('web')->user()->id == 1): ?>
                                        <?php echo e(asset('admin_template/app-assets/images/ico/zariq_favicon.ico')); ?>

                                        <?php else: ?>
                                        <?php echo e(asset('admin_template/app-assets/images/portrait/small/avatar-s-11.jpg')); ?>

                                        <?php endif; ?>"
                                        alt="avatar" height="40" width="40"></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right pb-0">
                                <div class="dropdown-divider mb-0"></div><a class="dropdown-item"
                                    href="<?php echo e(route('admin.logout')); ?>"><i class="bx bx-power-off mr-50"></i>
                                    Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <!-- END: Header-->

    <!-- BEGIN: Main Menu-->
    <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
        <div class="navbar-header">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item mr-auto"><a class="navbar-brand" href="<?php echo e(route('admin.dashboard')); ?>">
                        <div class="brand-logo">
                            <img class="logo" style="height: 30px;"
                                src="<?php echo e(asset('images/setting/'.$company->logo)); ?>" />
                            </div>
                        
                    </a></li>
                <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i
                            class="bx bx-x d-block d-xl-none font-medium-4 primary toggle-icon"></i><i
                            class="toggle-icon bx bx-disc font-medium-4 d-none d-xl-block collapse-toggle-icon primary"
                            data-ticon="bx-disc"></i></a></li>
            </ul>
        </div>
        <div class="shadow-bottom"></div>
        <div class="main-menu-content">
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation"
                data-icon-style="">

                <li class=" navigation-header"><span>Client View</span>
                </li>
                <li class=" nav-item"><a href="<?php echo e(route('homepage')); ?>"><i class="bx bx-globe"></i><span
                            class="menu-title">Website</span></a>
                </li>
                <li class=" navigation-header"><span>Home Page</span>
                </li>
                <li class=" nav-item"><a href="<?php echo e(route('slider')); ?>"><i class="bx bxs-map-alt"></i><span
                            class="menu-title">Home page Slider</span></a>
                </li>
                
                 <li class=" nav-item"><a href="#"><i class="bx bxs-categories"></i><span
                            class="menu-title">About Tab</span></a>
                </li>
                
                 <li class=" nav-item"><a href="#"><i class="bx
                    bxs-archive-in"></i><span
                            class="menu-title">Client Review</span></a>
                </li>
                 

                
                  
                <li class=" navigation-header"><span>Product Section</span></li>
                    <li class=" nav-item"><a href="<?php echo e(route('product.create')); ?>"><i class="bx bx-cart-alt"></i><span
                            class="menu-title">Add Product</span></a>
                    </li>
                    <li class=" nav-item"><a href="<?php echo e(route('product.index')); ?>"><i class="bx bx-cart-alt"></i><span
                            class="menu-title">Product List</span></a>
                    </li>
                    <li class=" nav-item"><a href="#"><i class="bx bx-cart-alt"></i><span
                            class="menu-title">Product Variation</span></a>
                    </li>
                    <li class=" nav-item"><a href="#"><i class="bx bx-cart-alt"></i><span
                            class="menu-title">Vendor Product List</span></a>
                    </li>
                <li class=" navigation-header"><span>Order Section</span></li>
                    <li class=" nav-item"><a href="#"><i class="bx bx-cart-alt"></i><span
                            class="menu-title">New Order</span></a>
                    </li>
                    <li class=" nav-item"><a href="#"><i class="bx bx-cart-alt"></i><span
                            class="menu-title">Confirm Order</span></a>
                    </li>
                    <li class=" nav-item"><a href="#"><i class="bx bx-cart-alt"></i><span
                            class="menu-title">Shipping Order</span></a>
                    </li>
                    <li class=" nav-item"><a href="#"><i class="bx bx-cart-alt"></i><span
                            class="menu-title">Delivered Order</span></a>
                    </li>
                    <li class=" nav-item"><a href="#"><i class="bx bx-cart-alt"></i><span
                            class="menu-title">Cancel Order</span></a>
                    </li>

                <!-- Contact Page -->
                
                <li class=" navigation-header"><span>Blog Section</span></li>

                <li class=" nav-item"><a href="#"><i class="bx bx-detail"></i><span class="menu-title">Blog Section</span></a>
                    <ul class='menu-content'>
                        <li><a href="<?php echo e(route('blog-category')); ?>"><i class="bx bx-right-arrow-alt"></i><span
                                    class="menu-item" data-i18n="LivIcons">Category</span></a>
                        </li>
                        <li><a href="<?php echo e(route('blog.index')); ?>"><i class="bx bx-right-arrow-alt"></i><span
                                    class="menu-item" data-i18n="LivIcons">Blog</span></a>
                        </li>
                    </ul>
                </li>


                <li class=" navigation-header"><span>Settings</span>
                </li>
                <li class=" nav-item"><a href="<?php echo e(route('settings.update')); ?>"><i class="bx bx-badge"></i><span
                            class="menu-title">Basic Setting</span></a>
                </li>
                <li class=" nav-item"><a href="<?php echo e(route('brand')); ?>"><i class="bx bx-badge"></i><span
                            class="menu-title">Brand</span></a>
                </li>
                <li class=" nav-item"><a href="<?php echo e(route('company')); ?>"><i class="bx bx-badge"></i><span
                            class="menu-title">Company</span></a>
                </li>
                <li class=" nav-item"><a href="<?php echo e(route('catalogue.index')); ?>"><i class="bx bx-badge"></i><span
                            class="menu-title">Catalogue</span></a>
                </li>
                <li class=" nav-item"><a href="<?php echo e(route('category.index')); ?>"><i class="bx bx-badge"></i><span
                            class="menu-title">Category</span></a>
                </li>
                <li class=" nav-item"><a href="<?php echo e(route('product.attribute')); ?>"><i class="bx bx-badge"></i><span
                            class="menu-title">Product Attribute</span></a>
                </li>
                <li class=" nav-item"><a href="<?php echo e(route('product.attributeValue')); ?>"><i class="bx bx-badge"></i><span
                            class="menu-title">Attribute Value</span></a>
                </li>
                <li class=" nav-item"><a href="<?php echo e(route('bike.index')); ?>"><i class="bx bx-badge"></i><span
                            class="menu-title">Bikes</span></a>
                </li>
                

                

                        
                    

            </ul>
        </div>
    </div>
    <!-- END: Main Menu-->
<?php /**PATH C:\xampp\htdocs\bongshal\resources\views/backend/layout/menu.blade.php ENDPATH**/ ?>