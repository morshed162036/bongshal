<?php $__env->startSection('css'); ?>
    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/vendors/css/vendors.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/vendors/css/tables/datatable/datatables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/vendors/css/charts/apexcharts.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/vendors/css/pickers/daterange/daterangepicker.css')); ?>">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/css/bootstrap-extended.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/css/colors.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/css/components.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/css/themes/dark-layout.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/css/themes/semi-dark-layout.css')); ?>">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/css/core/menu/menu-types/vertical-menu.css')); ?>">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/assets/css/style.css')); ?>">
    <!-- END: Custom CSS-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-header row">
    <div class="content-header-left col-12 mb-2 mt-1">
        <div class="row breadcrumbs-top">
            <div class="col-12">
                <h5 class="content-header-title float-left pr-1 mb-0">Basic Settings</h5>
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
                        </li>
                        <li class="breadcrumb-item active">Company Details Edit
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="content-body">

    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <!-- Basic Inputs start -->
    <section id="basic-input">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-content">
                        <form action="<?php echo e(route('settings.update')); ?>" method="post" enctype="multipart/form-data"> <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-10">
                                        <fieldset>
                                            <h5>Logo</h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-file"></i></span>
                                                </div>
                                                <input type="file" class="form-control" aria-describedby="basic-Createon1" name="logo" onchange="loadLogo(event)">
                                            </div>
                                        </fieldset>
                                        <?php if($company->logo != null): ?>
                                        <img src="<?php echo e(asset('images/setting/'.$company->logo)); ?>" id="logo" alt="logo" width="300px" height="100px" class="mt-2 mx-1">
                                        <?php endif; ?>
                                        <fieldset class="mt-2">
                                            <h5>Favicon</h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-file"></i></span>
                                                </div>
                                                <input type="file" class="form-control" aria-describedby="basic-Createon1" name="favicon" onchange="loadFavicon(event)">
                                            </div>
                                        </fieldset>
                                        <?php if($company->favicon != null): ?>
                                        <img src="<?php echo e(asset('images/setting/'.$company->favicon)); ?>" id="favicon" alt="favicon" width="100px" height="100px" class="mt-2 mx-1">
                                        <?php endif; ?>
                                        <fieldset class="mt-2">
                                            <h5>SOS Banner</h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-file"></i></span>
                                                </div>
                                                <input type="file" class="form-control" aria-describedby="basic-Createon1" name="sos_banner" onchange="loadBanner(event)">
                                            </div>
                                        </fieldset>
                                        <?php if($company->sos_banner != null): ?>
                                        <img src="<?php echo e(asset('images/setting/'.$company->sos_banner)); ?>" id="sos_banner" alt="sos_banner" width="500px" height="150px" class="mt-2 mx-1">
                                        <?php endif; ?>
                                        

                                        <fieldset class="mt-2">
                                            <h5>Company Name <span class="star">*</span></h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <input type="text" name="site_name" class="form-control" <?php if($company->site_name): ?>
                                                value="<?php echo e($company->site_name); ?>"
                                                <?php endif; ?> required>
                                            </div>
                                        </fieldset>
                                        <fieldset class="mt-2">
                                            <h5>Phone <span class="star">*</span></h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <input type="text" name="phone" class="form-control"
                                                <?php if($company->phone): ?>
                                                value="<?php echo e($company->phone); ?>"
                                                <?php endif; ?> required>
                                            </div>
                                        </fieldset>
                                        <fieldset class="mt-2">
                                            <h5>Email <span class="star">*</span></h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <input type="email" name="email" class="form-control"
                                                <?php if($company->email): ?>
                                                value="<?php echo e($company->email); ?>"
                                                <?php endif; ?> required>
                                            </div>
                                        </fieldset>
                                        <fieldset class="mt-2">
                                            <h5>Whatsapp <span class="star">*</span></h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <input type="text" name="whatsapp" class="form-control"
                                                <?php if($company->whatsapp): ?>
                                                value="<?php echo e($company->whatsapp); ?>"
                                                <?php endif; ?> required>
                                            </div>
                                        </fieldset>
                                        <fieldset class="mt-2">
                                            <h5>Address <span class="star">*</span></h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <textarea class="form-control" id="basicTextarea" rows="3" placeholder="" name="address"  required><?php echo e($company->address); ?></textarea>
                                            </div>
                                        </fieldset>

                                        <fieldset class="mt-2">
                                            <h5>Facebook Link</h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <input type="text" name="social_facebook" class="form-control"
                                                <?php if($company->social_facebook): ?>
                                                value="<?php echo e($company->social_facebook); ?>"
                                                <?php endif; ?>>
                                            </div>
                                        </fieldset>
                                        <fieldset class="mt-2">
                                            <h5>Twitter Link</h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <input type="text" name="social_twitter" class="form-control"
                                                <?php if($company->social_twitter): ?>
                                                value="<?php echo e($company->social_twitter); ?>"
                                                <?php endif; ?>>
                                            </div>
                                        </fieldset>
                                        <fieldset class="mt-2">
                                            <h5>Youtube Link</h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <input type="text" name="social_youtube" class="form-control"
                                                <?php if($company->social_youtube): ?>
                                                value="<?php echo e($company->social_youtube); ?>"
                                                <?php endif; ?>>
                                            </div>
                                        </fieldset>
                                        <fieldset class="mt-2">
                                            <h5>Instagram Link</h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <input type="text" name="social_instagram" class="form-control"
                                                <?php if($company->social_instagram): ?>
                                                value="<?php echo e($company->social_instagram); ?>"
                                                <?php endif; ?>>
                                            </div>
                                        </fieldset>
                                        <fieldset class="mt-2">
                                            <h5>Footer About</h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <textarea class="form-control" id="basicTextarea" rows="3" placeholder="" name="short_about"><?php echo e($company->short_about); ?></textarea>
                                            </div>
                                        </fieldset>
                                        <fieldset class="mt-2">
                                            <h5>Copyright</h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <textarea class="form-control" id="basicTextarea" rows="3" placeholder="" name="copyright"><?php echo e($company->copyright); ?></textarea>
                                            </div>
                                        </fieldset>
                                        <fieldset class="mt-2">
                                            <h5>Meta Tag</h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <textarea class="form-control" id="text" name="meta_tag"><?php echo e($company->meta_tag); ?></textarea>
                                            </div>
                                        </fieldset>
                                        <fieldset class="mt-2">
                                            <h5>Meta Keywords</h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <textarea class="form-control" id="text" name="meta_keyword"><?php echo e($company->meta_keyword); ?></textarea>
                                            </div>
                                        </fieldset>
                                        <fieldset class="mt-2">
                                            <h5>Meta Description</h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <textarea class="form-control" id="basicTextarea" rows="3" placeholder="" name="meta_description"><?php echo e($company->meta_description); ?></textarea>
                                            </div>
                                        </fieldset>
                                        <fieldset class="mt-2">
                                            <h5>Google Analytics Code</h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <textarea class="form-control" id="basicTextarea" rows="3" placeholder="" name="google_analytics_code"><?php echo e($company->google_analytics_code); ?></textarea>
                                            </div>
                                        </fieldset>
                                        <fieldset class="mt-2">
                                            <h5>Facebook Pixel Code</h5>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-Createon1"><i class="bx bx-spreadsheet"></i></span>
                                                </div>
                                                <textarea class="form-control" id="basicTextarea" rows="3" placeholder="" name="facebook_pixel_code"><?php echo e($company->facebook_pixel_code); ?></textarea>
                                            </div>
                                        </fieldset>

                                        <button type="submit" class="btn btn-primary mt-2 btn-lg mx-1">Update</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Basic Inputs end -->

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- BEGIN: Vendor JS-->
    <script src="<?php echo e(asset('admin_template/app-assets/vendors/js/vendors.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.tools.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.defaults.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.min.js')); ?>"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo e(asset('admin_template/app-assets/vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/vendors/js/charts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/vendors/js/pickers/daterange/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/vendors/js/pickers/daterange/daterangepicker.js')); ?>"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo e(asset('admin_template/app-assets/js/core/app-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/js/core/app.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/js/scripts/components.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/js/scripts/footer.js')); ?>"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="<?php echo e(asset('admin_template/app-assets/js/scripts/pages/table-extended.js')); ?>"></script>
    <!-- END: Page JS-->
    <script>
        var loadLogo = function(event) {
            var logo = document.getElementById('logo');
            logo.src = URL.createObjectURL(event.target.files[0]);
            logo.height =  '100';
        }
        var loadFavicon = function(event) {
            var favicon = document.getElementById('favicon');
            favicon.src = URL.createObjectURL(event.target.files[0]);
            favicon.height =  '100';
        }
        var loadBanner = function(event) {
            var sos_banner = document.getElementById('sos_banner');
            sos_banner.src = URL.createObjectURL(event.target.files[0]);
            sos_banner.height =  '100';
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bongshal\resources\views/backend/settings.blade.php ENDPATH**/ ?>