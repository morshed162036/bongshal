<?php $__env->startSection('css'); ?>
    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/vendors/css/vendors.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/vendors/css/tables/datatable/datatables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/vendors/css/charts/apexcharts.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/vendors/css/pickers/daterange/daterangepicker.css')); ?>">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/css/bootstrap-extended.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/css/colors.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/css/components.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/css/themes/dark-layout.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/css/themes/semi-dark-layout.css')); ?>">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/app-assets/css/core/menu/menu-types/vertical-menu.css')); ?>">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_template/assets/css/style.css')); ?>">
    <!-- END: Custom CSS-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-header row">
    <div class="content-header-left col-12 mb-2 mt-1">
        <div class="row breadcrumbs-top">
            <div class="col-12">
                <h5 class="content-header-title float-left pr-1 mb-0">Bike Edit</h5>
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
                        </li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('bike.index')); ?>">Bikes</a>
                        </li>
                        <li class="breadcrumb-item active">Bike Edit
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="content-body">
    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success: </strong><?php echo e(Session::get('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Error: </strong><?php echo e(Session::get('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <form class="form" action="<?php echo e(route('bike.update', $bike->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Bike Edit Form</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label for="company_id">Company <span class="text-danger">*</span></label>
                                        <select name="company_id" id="company_id" class="form-control" required>
                                            <option value="" disabled selected>Select Company</option>
                                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($company->id); ?>" <?php echo e($bike->company_id == $company->id ? 'selected' : ''); ?>><?php echo e($company->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label for="model_name">Model Name <span class="text-danger">*</span></label>
                                        <input type="text" id="model_name" class="form-control" name="model" value="<?php echo e($bike->model); ?>" placeholder="Enter Model Name" required>
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label for="battery">Battery <span class="text-danger">*</span></label>
                                        <input type="text" id="battery" class="form-control" name="battery_capacity" value="<?php echo e($bike->battery); ?>" placeholder="Enter Battery" required>
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label for="front_tire_size">Front Tire Size <span class="text-danger">*</span></label>
                                        <input type="text" id="front_tire_size" class="form-control" name="front_tire_size" value="<?php echo e($bike->front_tire_size); ?>" placeholder="Enter Front Tire Size" required>
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label for="rear_tire_size">Rear Tire Size <span class="text-danger">*</span></label>
                                        <input type="text" id="rear_tire_size" class="form-control" name="rear_tire_size" value="<?php echo e($bike->rear_tire_size); ?>" placeholder="Enter Rear Tire Size" required>
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label for="type">Type <span class="text-danger">*</span></label>
                                        <select name="type" id="type" class="form-control" required>
                                            <option value="" disabled selected>Select Type</option>
                                            <option value="scooty" <?php echo e($bike->type == 'scooty' ? 'selected' : ''); ?>>Scooty</option>
                                            <option value="street" <?php echo e($bike->type == 'street' ? 'selected' : ''); ?>>Street / Naked</option>
                                            <option value="sports" <?php echo e($bike->type == 'sports' ? 'selected' : ''); ?>>Sports</option>

                                    </div>
                                </div>

                                <div class="col-md-6 col-12">
                                    <div class="form-group">

                                        <input type="hidden" id="price" class="form-control" name="price" placeholder="Enter Price">
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <h5>Bike Colors</h5>
                            <div id="color-container">
                                <?php $__currentLoopData = $bike->color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row color-group" data-index="<?php echo e($index); ?>">
                                        <div class="col-md-4 col-12">
                                            <div class="form-group">
                                                <label for="color_<?php echo e($index); ?>">Color Name <span class="text-danger">*</span></label>
                                                <input type="hidden" id="color_<?php echo e($index); ?>" class="form-control" name="group-color[<?php echo e($index); ?>][id]" value="<?php echo e($color->id); ?>" placeholder="Enter Color Name" required>
                                                <input type="text" id="color_<?php echo e($index); ?>" class="form-control" name="group-color[<?php echo e($index); ?>][color]" value="<?php echo e($color->color_name); ?>" placeholder="Enter Color Name" required>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-12">
                                            <div class="form-group">
                                                <label for="color_image_<?php echo e($index); ?>">Color Image <span class="text-danger">*</span></label>
                                                <input type="file" id="color_image_<?php echo e($index); ?>" class="form-control" name="group-color[<?php echo e($index); ?>][image]" onchange="loadFile(event)">
                                                <?php if($color->image): ?>
                                                    <img src="<?php echo e(asset('images/multiimage/bike/'.$color->image)); ?>" alt="Color Image" width="150" class="mt-2">
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-12 d-flex align-items-end">
                                            <button type="button" class="btn btn-danger remove-color-btn" onclick="removeColor(this)">Remove Color</button>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="btn btn-primary" id="add-color-btn">Add Color</button>
                            <hr>
                            <h5>Bike Grades</h5>
                            <div id="grade-container">
                                <?php $__currentLoopData = $bike->grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row grade-group" data-index="<?php echo e($index); ?>">
                                        <div class="col-md-4 col-12">
                                            <div class="form-group">
                                                <label for="grade_<?php echo e($index); ?>">Grade <span class="text-danger">*</span></label>
                                                <input type="hidden" class="form-control" name="group-grade[<?php echo e($index); ?>][id]" value="<?php echo e($grade->id); ?>">
                                                <input type="text" id="grade_<?php echo e($index); ?>" class="form-control" name="group-grade[<?php echo e($index); ?>][grade]" value="<?php echo e($grade->grade); ?>" placeholder="Enter Grade" required>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-12">
                                            <div class="form-group">
                                                <label for="volume_<?php echo e($index); ?>">Volume <span class="text-danger">*</span></label>
                                                <input type="text" id="volume_<?php echo e($index); ?>" class="form-control" name="group-grade[<?php echo e($index); ?>][volume]" value="<?php echo e($grade->volume); ?>" placeholder="Enter Volume" required>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-12 d-flex align-items-end">
                                            <button type="button" class="btn btn-danger remove-grade-btn" onclick="removeGrade(this)">Remove Grade</button>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="btn btn-primary" id="add-grade-btn">Add Grade</button>
                            <hr>
                            <div class="form-group">
                                <button type="submit" class="btn btn-success">Update Bike</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- BEGIN: Vendor JS-->
    <script src="<?php echo e(asset('admin_template/app-assets/vendors/js/vendors.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.tools.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.defaults.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.min.js')); ?>"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo e(asset('admin_template/app-assets/vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/vendors/js/charts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/vendors/js/pickers/daterange/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/vendors/js/pickers/daterange/daterangepicker.js')); ?>"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo e(asset('admin_template/app-assets/js/core/app-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/js/core/app.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/js/scripts/components.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/js/scripts/footer.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/js/scripts/forms/form-repeater.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/app-assets/vendors/js/forms/repeater/jquery.repeater.min.js')); ?>"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="<?php echo e(asset('admin_template/app-assets/js/scripts/pages/table-extended.js')); ?>"></script>
    <!-- END: Page JS-->

    
    <script>
        let colorIndex = <?php echo e(count($bike->color)); ?>;
        let gradeIndex = <?php echo e(count($bike->grade)); ?>;

        document.getElementById('add-color-btn').addEventListener('click', function() {
            const container = document.getElementById('color-container');
            const colorGroup = document.createElement('div');
            colorGroup.classList.add('row', 'color-group');
            colorGroup.setAttribute('data-index', colorIndex);

            colorGroup.innerHTML = `
                <div class="col-md-4 col-12">
                    <div class="form-group">
                        <label for="color_${colorIndex}">Color Name <span class="text-danger">*</span></label>
                        <input type="hidden" class="form-control" name="group-color[${colorIndex}][color]" placeholder="Enter Color Name" required>
                        <input type="text" id="color_${colorIndex}" class="form-control" name="group-color[${colorIndex}][color]" placeholder="Enter Color Name" required>
                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <div class="form-group">
                        <label for="color_image_${colorIndex}">Color Image <span class="text-danger">*</span></label>
                        <input type="file" id="color_image_${colorIndex}" class="form-control" name="group-color[${colorIndex}][image]" onchange="loadFile(event)">
                    </div>
                </div>
                <div class="col-md-4 col-12 d-flex align-items-end">
                    <button type="button" class="btn btn-danger remove-color-btn" onclick="removeColor(this)">Remove Color</button>
                </div>
            `;
            container.appendChild(colorGroup);
            colorIndex++;
        });
        function removeColor(button) {
            const colorGroup = button.closest('.color-group');
            colorGroup.remove();
        }
        document.getElementById('add-grade-btn').addEventListener('click', function() {
            const container = document.getElementById('grade-container');
            const gradeGroup = document.createElement('div');
            gradeGroup.classList.add('row', 'grade-group');
            gradeGroup.setAttribute('data-index', gradeIndex);

            gradeGroup.innerHTML = `
                <div class="col-md-4 col-12">
                    <div class="form-group">
                        <label for="grade_${gradeIndex}">Grade <span class="text-danger">*</span></label>
                        <input type="text" id="grade_${gradeIndex}" class="form-control" name="group-grade[${gradeIndex}][grade]" placeholder="Enter Grade" required>
                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <div class="form-group">
                        <label for="volume_${gradeIndex}">Volume <span class="text-danger">*</span></label>
                        <input type="text" id="volume_${gradeIndex}" class="form-control" name="group-grade[${gradeIndex}][volume]" placeholder="Enter Volume" required>
                    </div>
                </div>
                <div class="col-md-4 col-12 d-flex align-items-end">
                    <button type="button" class="btn btn-danger remove-grade-btn" onclick="removeGrade(this)">Remove Grade</button>
                </div>
            `;
            container.appendChild(gradeGroup);
            gradeIndex++;
        });
        function removeGrade(button) {
            const gradeGroup = button.closest('.grade-group');
            gradeGroup.remove();
        }
    </script>
    <script>
        var loadFile = function(event) {
            var output = document.getElementById('output');
            output.src = URL.createObjectURL(event.target.files[0]);
            output.height =  '200';
        }
    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('backend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bongshal\resources\views/backend/bikes/edit.blade.php ENDPATH**/ ?>